<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
          Pengetahuan
          <small>Master</small>
      </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-file-text-o"></i> Pengetahuan</a></li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
          <div class="col-md-3">
            <div class="box box-success">
                <div class="box-header">
                    <h3 class="box-title">Tambah Pengetahuan</h3>
                </div><!-- /.box-header -->

                <!-- form start -->
                <form action="<?php echo base_url()."index.php/control_pengetahuan/insert" ?>" method="post" onsubmit="return cekform()">
                    <div class="box-body">
                        <div class="form-group">
                            <label>Fakta</label>
                            <select id="pilihan_awal" name="fakta" class="form-control">
                              <?php foreach ($pilihan_fakta as $d) { ?>

                                <option><?php echo "$d[kode] - $d[nama_fakta]"; ?></option>
                            <?php }  ?>
                            </select>
                        </div>
                        <div class="form-group">
                          <label>Jawaban Ya</label>
                          <input type="text" class="form-control" placeholder="Isi Jika Jawaban Ya" name="jwya" id="jwya">
                        </div>
                        <div class="form-group">
                          <label>Jawaban Tidak</label>
                          <input type="text" class="form-control" placeholder="Isi Jika Jawaban Tidak" name="jwtdk" id="jwtdk">
                        </div>

                        <!-- jawaban ya -->
                        <div class="form-group col-md-6 col-sm-12">
                          <label>Ya</label>
                          <div class="radio form-inline">
                            <label>
                              <input type="radio" name="optionsRadios">
                              <select id="faktaya" class="form-control" oninput="nilaifakta_ya()" onclick="pindahyasatu()">
                                <option value=""> ---- </option>
                                <?php foreach ($pilihan_fakta as $dfsatu) {
                                echo "<option value='$dfsatu[kode]'>".$dfsatu[kode]."</option>";}
                                ?>
                              </select>
                            </label>
                          </div>
                          <div class="radio form-inline">
                            <label>
                              <input type="radio" name="optionsRadios">
                              <select id="goalya" class="form-control" oninput="nilaigoal_ya()" onclick="pindahyadua()">
                                <option value=""> ---- </option>
                                <?php foreach ($pilihan_goal as $dgsatu) {
                                echo "<option value='$dgsatu[kode]'>".$dgsatu[kode]."</option>";}
                                ?>
                              </select>
                            </label>
                          </div>
                        </div>

                        <!-- Jawaban Tidak -->
                        <div class="form-group col-md-6">
                          <label>Tidak</label>
                          <div class="radio form-inline">
                            <label>
                              <input type="radio" name="optionsRadios1">
                              <select id="faktatidak" class="form-control" oninput="nilaifakta_tidak()" onclick="pindahtidaksatu()">
                                <option value=""> ---- </option>
                                <?php foreach ($pilihan_fakta as $dfdua) {
                                echo "<option value='$dfdua[kode]'>".$dfdua[kode]."</option>";}
                                ?>
                              </select>
                            </label>
                          </div>
                          <div class="radio form-inline">
                            <label>
                              <input type="radio" name="optionsRadios1">
                              <select id="goaltidak" class="form-control" oninput="nilaigoal_tidak()" onclick="pindahtidakdua()">
                                <option value=""> ---- </option>
                                <?php foreach ($pilihan_goal as $dgdua) {
                                echo "<option value='$dgdua[kode]'>".$dgdua[kode]."</option>";}
                                ?>
                              </select>
                            </label>
                          </div>
                        </div>
                        <input type="hidden" name="k_ya" id="kode_ya">
                        <input type="hidden" name="k_tdk" id="kode_tidak">

                      </div><!-- /.box-body -->
                    <div class="box-footer">
                      <button type="submit" class="btn bg-olive btn-block">Simpan</button>
                       <!-- <a href="javascript:void(0)" onclick="konfirmasi()" class="btn btn-info" role="button">Simpan</a> -->
                       <!-- <button type="submit" class="btn btn-primary"><a href="formpenyakit1.html">Simpan</a></button>-->
                    </div>
                </form>
            </div><!-- /.box -->
          </div>

          <div class="col-md-9">
            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title">Pengetahuan</h3>
                </div><!-- /.box-header -->

                <div class="box-body table-responsive">
                    <table id="example1" class="table table-bordered table-striped">
                        <div class="contains">
                            <!-- <span>
                                <a href="<?php echo base_url()."index.php/tampil/formpengetahuan" ?>" class="btn btn-info">Tambah</a>
                            </span> -->
                        </div>
                            <br>
                        <thead>
                            <tr>
                                <th class="text-center" style="width: 25px">No</th>
                                <th class="text-center" style="width: 50px">Fakta</th>
                                <th style="width: 100px">Jawaban Ya</th>
                                <th style="width: 100px">Jawaban Tidak</th>
                                <th class="text-center" style="width: 50px">Ya</th>
                                <th class="text-center" style="width: 50px">Tidak</th>
                                <th class="text-center" style="width: 100px">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php $x=1; foreach ($hasil as $d) { ?>

                            <tr>
                                <td class="text-center"><?php echo $x; ?></td>
                                <td class="text-center"><?php echo $d['kode_fakta']; ?></td>
                                <td><?php echo $d['jawabya']; ?></td>
                                <td><?php echo $d['jawabtdk']; ?></td>
                                <td class="text-center"><?php echo $d['ya']; ?></td>
                                <td class="text-center"><?php echo $d['tdk']; ?></td>
                                <td class="text-center"><a href="<?php echo base_url()."index.php/tampil/formeditpengetahuan/".$d['kode_pengetahuan'];?>">Edit</a> |
                                  <a href="<?php echo base_url()."index.php/control_pengetahuan/delete/".$d['kode_pengetahuan'];?>" onclick="return konfirmasi()">Delete</a></td>
                            </tr>
                          <?php $x++; } ?>
                    </table>
                </div><!-- /.box-body -->
            </div><!-- /.box -->
          </div>

        </div>

    </section><!-- /.content -->
</aside><!-- /.right-side -->
<script type="text/javascript" language="javascript">
  function nilaifakta_ya() {
      var fakta_ya = $('#faktaya').val();
      console.log('aaa'+fakta_ya);
      document.getElementById('kode_ya').value = fakta_ya;
  }
  function nilaigoal_ya() {
      var goal_ya = $('#goalya').val();
      console.log('bbb'+goal_ya);
      document.getElementById('kode_ya').value = goal_ya;
  }
  function nilaifakta_tidak() {
      var fakta_tidak = $('#faktatidak').val();
      console.log('aaa'+fakta_tidak);
      document.getElementById('kode_tidak').value = fakta_tidak;
  }
  function nilaigoal_tidak() {
      var goal_tidak = $('#goaltidak').val();
      console.log('bbb'+goal_tidak);
      document.getElementById('kode_tidak').value = goal_tidak;
  }


  function pindahyasatu() {
      document.getElementById("goalya").selectedIndex = "0";
  }
  function pindahyadua() {
      document.getElementById("faktaya").selectedIndex = "0";
  }
  function pindahtidaksatu() {
      document.getElementById("goaltidak").selectedIndex = "0";
  }
  function pindahtidakdua() {
      document.getElementById("faktatidak").selectedIndex = "0";
  }


  function cekform(){

    if (!$("#pilihan_awal").val())
    {
        alert("Maaf, Pilihan Fakta Tidak Boleh Kosong");
        $("#pilihan_awal").focus();
        return false;

    }

    if (!$("#jwya").val())
    {
        alert("Maaf, Jawaban(Ya) Tidak Boleh Kosong");
        $("#jwya").focus();
        return false;

    }
    if (!$("#jwtdk").val())
    {
        alert("Maaf, Jawaban(Tidak) Tidak Boleh Kosong");
        $("#jwtdk").focus();
        return false;
    }
    if (!$("#kode_ya").val())
    {
        alert("Maaf, Pilih Pada Pilihan Ya");
        $("#kode_ya").focus();
        return false;
    }
    if (!$("#kode_tidak").val())
    {
        alert("Maaf, Pilih Pada Pilihan Tidak");
        $("#kode_tidak").focus();
        return false;
    }
  }

  function konfirmasi()
  {
    tanya = confirm("Anda Yakin Ingin Menghapus Data?");
    if (tanya == true)
    {
      return true;
    }
    else
    {
      return false;
    }
  }

</script>
