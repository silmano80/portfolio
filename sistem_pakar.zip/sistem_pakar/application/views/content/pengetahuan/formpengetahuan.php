<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
          Pengetahuan
          <small>Edit</small>
      </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-file-text-o"></i> Master Pengetahuan</a></li>
            <li class="active">Edit Pengetahuan</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-success">
                    <div class="box-header">
                        <h3 class="box-title">Pembaruan Pengetahuan</h3>
                    </div><!-- /.box-header -->

                    <!-- form start -->
                    <form action="<?php echo base_url()."index.php/control_pengetahuan/update" ?>" id="frm_peng" method="post" onSubmit="return cekform()">
                        <div class="box-body">
                            <div class="form-group">
                                <label>Fakta</label>
                                <select name="fakta" class="form-control">
                                  <?php foreach ($pilihan_fakta as $d) { ?>
                                    <option <?php if($d['kode']==$hasil['kode_fakta']){ echo "selected";}?> value="<?php echo $d['kode']; ?>"><?php echo "$d[kode] - $d[nama_fakta]"; ?></option>
                                <?php }  ?>
                                </select>
                            </div>
                            <div class="form-group">
                              <label>Jawaban Ya</label>
                              <input type="text" class="form-control" placeholder="Isi Jika Jawaban Ya" name="jwya" id="jwya" value="<?php echo $hasil['jawabya'];?>">
                            </div>
                            <div class="form-group">
                              <label>Jawaban Tidak</label>
                              <input type="text" class="form-control" placeholder="Isi Jika Jawaban Tidak" name="jwtdk" id="jwtdk" value="<?php echo $hasil['jawabtdk'];?>">
                            </div>

                            <!-- jawaban ya -->
                            <div class="form-group col-md-3 col-sm-12">
                              <label>Ya</label>
                              <div class="radio form-inline">
                                <label>
                                  <input type="radio" name="optionsRadios">
                                  <select id="faktaya" class="form-control" oninput="nilaifakta_ya()" onclick="pindahyasatu()">
                                    <option value=""> ---- </option>
                                    <?php foreach ($pilihan_fakta as $dfsatu) { ?>
                                    <option <?php if($dfsatu['kode']==$hasil['ya']){ echo "selected";}?> value="<?php echo $dfsatu['kode']; ?>"><?php echo $dfsatu['kode']; ?></option>
                                  <?php }
                                    ?>
                                  </select>
                                </label>
                              </div>
                              <div class="radio form-inline">
                                <label>
                                  <input type="radio" name="optionsRadios">
                                  <select id="goalya" class="form-control" oninput="nilaigoal_ya()" onclick="pindahyadua()">
                                    <option value=""> ---- </option>
                                    <?php foreach ($pilihan_goal as $dgsatu) { ?>
                                    <option <?php if($dgsatu['kode']==$hasil['ya']){ echo "selected";}?> value="<?php echo $dgsatu['kode']; ?>"><?php echo $dgsatu['kode']; ?></option>
                                  <?php }
                                    ?>
                                  </select>
                                </label>
                              </div>
                            </div>

                            <!-- Jawaban Tidak -->
                            <div class="form-group">
                              <label>Tidak</label>
                              <div class="radio form-inline">
                                <label>
                                  <input type="radio" name="optionsRadios1">
                                  <select id="faktatidak" class="form-control" oninput="nilaifakta_tidak()" onclick="pindahtidaksatu()">
                                    <option value=""> ---- </option>
                                    <?php foreach ($pilihan_fakta as $dfdua) { ?>
                                    <option <?php if($dfdua['kode']==$hasil['tdk']){ echo "selected";}?> value="<?php echo $dfdua['kode']; ?>"><?php echo $dfdua['kode']; ?></option>
                                  <?php }
                                    ?>
                                  </select>
                                </label>
                              </div>
                              <div class="radio form-inline">
                                <label>
                                  <input type="radio" name="optionsRadios1">
                                  <select id="goaltidak" class="form-control" oninput="nilaigoal_tidak()" onclick="pindahtidakdua()">
                                    <option value=""> ---- </option>
                                    <?php foreach ($pilihan_goal as $dgdua) { ?>
                                    <option <?php if($dgdua['kode']==$hasil['tdk']){ echo "selected";}?> value="<?php echo $dgdua['kode']; ?>"><?php echo $dgdua['kode']; ?></option>
                                  <?php }
                                    ?>
                                  </select>
                                </label>
                              </div>
                            </div>

                            <input type="hidden" name="k_pengetahuan" value="<?php echo $hasil['kode_pengetahuan']; ?>">
                            <input type="hidden" name="k_ya" id="kode_ya" value="<?php echo $hasil['ya']; ?>">
                            <input type="hidden" name="k_tdk" id="kode_tidak" value="<?php echo $hasil['tdk']; ?>">

                          </div><!-- /.box-body -->
                        <div class="box-footer">
                          <button type="submit" class="btn bg-olive btn-primary">Ubah</button>
                           <!-- <a href="javascript:void(0)" onclick="konfirmasi()" class="btn btn-info" role="button">Simpan</a> -->
                           <!-- <button type="submit" class="btn btn-primary"><a href="formpenyakit1.html">Simpan</a></button>-->
                        </div>
                    </form>
                </div><!-- /.box -->
            </div>
        </div>
    </section><!-- /.content -->
</aside><!-- /.right-side -->

<script src="<?php echo base_url()."assets/" ?>js/jquery.validation.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript">
  function nilaifakta_ya() {
      var fakta_ya = $('#faktaya').val();
      console.log('aaa'+fakta_ya);
      document.getElementById('kode_ya').value = fakta_ya;
  }
  function nilaigoal_ya() {
      var goal_ya = $('#goalya').val();
      console.log('bbb'+goal_ya);
      document.getElementById('kode_ya').value = goal_ya;
  }
  function nilaifakta_tidak() {
      var fakta_tidak = $('#faktatidak').val();
      console.log('aaa'+fakta_tidak);
      document.getElementById('kode_tidak').value = fakta_tidak;
  }
  function nilaigoal_tidak() {
      var goal_tidak = $('#goaltidak').val();
      console.log('bbb'+goal_tidak);
      document.getElementById('kode_tidak').value = goal_tidak;
  }

  function pindahyasatu() {
      document.getElementById("goalya").selectedIndex = "0";
  }
  function pindahyadua() {
      document.getElementById("faktaya").selectedIndex = "0";
  }
  function pindahtidaksatu() {
      document.getElementById("goaltidak").selectedIndex = "0";
  }
  function pindahtidakdua() {
      document.getElementById("faktatidak").selectedIndex = "0";
  }

  function cekform(){

    if (!$("#jwya").val())
    {
        alert("Maaf, Jawaban(Ya) Tidak Boleh Kosong");
        $("#username").focus();
        return false;

    }
    if (!$("#jwtdk").val())
    {
        alert("Maaf, Jawaban(Tidak) Tidak Boleh Kosong");
        $("#jwtdk").focus();
        return false;
    }
    if (!$("#faktaya").val()&&!$("#goalya").val())
    {
        alert("Maaf, Pilih Pada Pilihan Ya");
        $("#username").focus();
        return false;

    }

    if (!$("#faktatidak").val()&&!$("#goaltidak").val())
    {
        alert("Maaf, Pilih Pada Pilihan Tidak");
        $("#username").focus();
        return false;

    }
  }

</script>
