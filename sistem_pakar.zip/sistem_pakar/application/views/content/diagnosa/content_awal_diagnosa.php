<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
          Diagnosa
          <small>Master</small>
      </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-comments-o"></i> Diagnosa</a></li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-solid">
                    <div class="box-header">
                        <h2 class="box-title">Klik Tombol Untuk Memulai Diagnosa!</h2>
                    </div><!-- /.box-header -->
                    <div class="box box-primary">

                    </div>
                    <div class="box-body">
                        <div class="box-group" id="accordion">
                            <!-- we are adding the .panel class so bootstrap.js collapse plugin detects it -->
                            <form action="<?php echo base_url()."index.php/tampil_diagnosa/masterdiagnosa"?>" method="post" onSubmit="" role="form">
                                <div class="box-body">
                                    <div class="form-group">
                                        <button type="submit" name="mulai" value="1" class="btn bg-olive btn-primary">Mulai Diagnosa</button>
                                        <!--<button  type="submit" class="btn btn-primary">Simpan</button>-->
                                    </div>
                                </div><!-- /.box-body -->
                            </form>
                        </div>
                    </div><!-- /.box-body -->
                </div><!-- /.box -->
            </div
          ><!-- /.col -->
    </section><!-- /.content -->
</aside><!-- /.right-side -->
