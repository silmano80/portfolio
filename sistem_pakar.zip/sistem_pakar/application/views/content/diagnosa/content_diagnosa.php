<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
          Diagnosa
          <small>Master</small>
      </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-comments-o"></i> Diagnosa</a></li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-solid">
                    <div class="box-header">
                        <h2 class="box-title">Jawab Pertanyaan Berikut Ini!</h2>
                    </div><!-- /.box-header -->
                    <div class="box box-primary">
                    </div>
                    <div class="box-body">
                        <div class="box-group" id="accordion">
                            <!-- we are adding the .panel class so bootstrap.js collapse plugin detects it -->
                            <form action="<?php echo base_url()."index.php/tampil_diagnosa/masterdiagnosa"?>" method="post" onSubmit="" role="form">
                                <div class="box-body">
                                    <div class="form-group">
                                        <h4>Apakah Anda <?php echo $hasil['nama_fakta']; ?> ?</h4>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" name="jawaban" class="btn bg-olive btn-primary" value="<?php echo $hasil['ya'] ?>"><?php echo $hasil['jawabya'] ?></button>
                                        <button type="submit" name="jawaban" class="btn bg-olive btn-primary" value="<?php echo $hasil['tdk'] ?>"><?php echo $hasil['jawabtdk'] ?></button>
                                        <!--<button  type="submit" class="btn btn-primary">Simpan</button>-->
                                    </div>
                                </div><!-- /.box-body -->
                            </form>
                        </div>
                    </div><!-- /.box-body -->
                </div><!-- /.box -->
            </div
          ><!-- /.col -->
    </section><!-- /.content -->
</aside><!-- /.right-side -->
