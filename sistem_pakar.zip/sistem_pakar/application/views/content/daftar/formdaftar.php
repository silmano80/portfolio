<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
          Daftar
          <small>Edit</small>
      </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-plus-square-o"></i> Daftar</a></li>
            <li class="active">Edit Daftar</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-success">
                    <div class="box-header">
                        <h3 class="box-title">Edit Daftar</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <form action="<?php echo base_url()."index.php/control_daftar/update"; ?>" method="post" onSubmit="" role="form">
                        <div class="box-body">
                          <div class="form-group">
                              <label>Username</label>
                              <input type="text" class="form-control"  id="username" readonly name="username" value="<?php echo $hasil['username']; ?>" placeholder="Masukkan Username">
                          </div>
                          <div class="form-group">
                              <label>Nama Depan</label>
                              <input type="text" class="form-control" id="nam_dep" name="nama_depan" value="<?php echo $hasil['nama_depan']; ?>" placeholder="Masukkan Nama Depan">
                          </div>

                          <div class="form-group">
                              <label>Nama Belakang</label>
                              <input type="text" class="form-control" id="nam_bel" name="nama_belakang" value="<?php echo $hasil['nama_belakang']; ?>" placeholder="Masukkan Nama Belakang">
                          </div>
                          <div class="form-group">
                            <label>Hak Akses</level>
                            <div class="radio">
                              <label>
                                <input type="radio" value="1" <?php if($hasil['id_level']==1) { echo "checked"; } ?> name="level"> Admin
                              </label>
                            </div>
                            <div class="radio">
                              <label>
                                <input type="radio" value="2" <?php if($hasil['id_level']==2) { echo "checked"; } ?> name="level"> Pengguna
                              </label>
                            </div>
                          </div>
                        </div><!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn bg-olive btn-primary">Pembaruan</button>
                            <!--<button  type="submit" class="btn btn-primary">Simpan</button>-->
                        </div>
                    </form>
                </div><!-- /.box -->
            </div>
        </div>
    </section><!-- /.content -->

    </section><!-- /.content -->
</aside><!-- /.right-side -->
