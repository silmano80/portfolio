<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
          Daftar
          <small>Master</small>
      </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-plus-square-o"></i> Daftar</a></li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
          <div class="col-md-3">
            <div class="box box-success">
                <div class="box-header">
                    <h3 class="box-title">Tambah Daftar</h3>
                </div><!-- /.box-header -->

                <!-- form start -->
                <form action="<?php echo base_url()."index.php/control_daftar/insert"; ?>" method="post" onSubmit="return cekform()" role="form">
                    <div class="box-body">
                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" class="form-control"  id="user" autofocus name="username" placeholder="Masukkan Username">
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" class="form-control" id="password" name="password" placeholder="Masukkan Password">
                        </div>
                        <?php echo $this->session->flashdata('pesan') ?>
                        <div class="form-group">
                            <label>Confirm Password</label>
                            <input type="password" class="form-control" id="con_password" name="con_password" placeholder="Masukkan Confirm Password">
                        </div>
                        <div class="form-group">
                            <label>Nama Depan</label>
                            <input type="text" class="form-control" id="nam_dep" name="nama_depan" placeholder="Masukkan Nama Depan">
                        </div>

                        <div class="form-group">
                            <label>Nama Belakang</label>
                            <input type="text" class="form-control" id="nam_bel" name="nama_belakang" placeholder="Masukkan Nama Belakang">
                        </div>
                        <div class="form-group">
                          <label>Hak Akses</level>
                          <div class="radio">
                            <label>
                              <input type="radio" value="1" checked name="level"> Admin
                            </label>
                          </div>
                          <div class="radio">
                            <label>
                              <input type="radio" value="2" name="level"> Pengguna
                            </label>
                          </div>
                        </div>

                    </div><!-- /.box-body -->

                    <div class="box-footer">
                        <button type="submit" class="btn bg-olive btn-block">Simpan</button>
                        <!--<button  type="submit" class="btn btn-primary">Simpan</button>-->
                    </div>
                </form>
            </div><!-- /.box -->

          </div>
          <div class="col-md-9">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Master Daftar</h3>
                    </div><!-- /.box-header -->

                    <div class="box-body table-responsive">
                        <div class="contains">
                            <span>
                                <!-- <a href="<?php echo base_url()."index.php/tampil/formfakta"; ?>" class="btn btn-info">Tambah</a> -->
                            </span>
                        </div>
                            <br>
                        <table id="example2" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th class="text-center" style="width: 75px">No</th>
                                    <th style="width: 150px">Username</th>
                                    <th style="width: 200px">Nama Depan</th>
                                    <th>Nama Belakang</th>
                                    <th style="width: 100px">Level</th>
                                    <th class="text-center" style="width: 100px">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                              <?php $x=1; foreach ($hasil as $d) { ?>

                                <tr>
                                  <td class="text-center"><?php echo $x; ?></td>
                                    <td><?php echo $d['username']; ?></td>
                                    <td><?php echo $d['nama_depan']; ?></td>
                                    <td><?php echo $d['nama_belakang']; ?></td>
                                    <td><?php if ($d['id_level']==1) {echo "Admin"; } else { echo "Pengguna"; }?></td>
                                    <td class="text-center"><a href="<?php echo base_url()."index.php/tampil/formeditdaftar/".$d['username']; ?>">Edit</a> | <a href="<?php echo base_url()."index.php/control_daftar/delete/".$d['username']; ?>" onclick="return konfirmasi();">Delete</a></td>
                                </tr>

                              <?php $x++; } ?>
                            </body>
                        </table>
                    </div><!-- /.box-body -->
                </div><!-- /.box -->
              </div>
            </div>
        </div>

    </section><!-- /.content -->
</aside>
<script type="text/javascript" language="javascript">
function cekform(){

  if (!$("#user").val())
  {
      alert("Maaf, Username Tidak Boleh Kosong");
      $("#username").focus();
      return false;

  }

  if (!$("#password").val())
  {
      alert("Maaf, Password Tidak Boleh Kosong");
      $("#password").focus();
      return false;

  }
  if (!$("#con_password").val())
  {
      alert("Isikan Konfirmasi Password Terlebih Dahulu");
      $("#con_password").focus();
      return false;

  }
  if (!$("#nam_dep").val())
  {
      alert("Maaf, Nama Depan Tidak Boleh Kosong");
      $("#nam_dep").focus();
      return false;
  }
  if (!$("#nam_bel").val())
  {
      alert("Maaf, Nama Belakang Tidak Boleh Kosong");
      $("#nam_bel").focus();
      return false;
  }
}

function konfirmasi()
{
  tanya = confirm("Anda Yakin Ingin Menghapus Data?");
  if (tanya == true)
  {
    return true;
  }
  else
  {
    return false;
  }
}

</script>
