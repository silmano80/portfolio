<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
          Fakta
          <small>Master</small>
      </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-folder-o"></i> Fakta</a></li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
          <div class="col-md-3">
            <div class="box box-success">
                <div class="box-header">
                    <h3 class="box-title">Tambah Fakta</h3>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form action="<?php echo base_url()."index.php/control_fakta/insert"; ?>" method="post" onSubmit="return cekform()" role="form">
                    <div class="box-body">
                        <div class="form-group">
                            <label>Kode Fakta</label>
                            <input type="text" class="form-control"  id="kode" name="kode" <?php echo "value=".$kode; ?>>
                        </div>
                        <div class="form-group">
                            <label>Nama Fakta</label>
                            <input type="text" class="form-control" id="fakta" name="fakta" autofocus placeholder="Masukkan fakta">
                        </div>
                    </div><!-- /.box-body -->

                    <div class="box-footer">
                        <button type="submit" class="btn bg-olive btn-block">Simpan</button>
                        <!--<button  type="submit" class="btn btn-primary">Simpan</button>-->
                    </div>
                </form>
            </div><!-- /.box -->

          </div>
          <div class="col-md-9">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Master Fakta</h3>
                    </div><!-- /.box-header -->

                    <div class="box-body table-responsive">
                        <div class="contains">
                            <span>
                                <!-- <a href="<?php echo base_url()."index.php/tampil/formfakta"; ?>" class="btn btn-info">Tambah</a> -->
                            </span>
                        </div>
                            <br>
                        <table id="example2" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th class="text-center" style="width: 75px">No</th>
                                    <th style="width: 300px">Kode Fakta</th>
                                    <th>Nama Fakta</th>
                                    <th class="text-center" style="width: 250px">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                              <?php $x=1; foreach ($hasil as $d) { ?>

                                <tr>
                                  <td class="text-center"><?php echo $x; ?></td>
                                    <td><?php echo $d['kode']; ?></td>
                                    <td><?php echo $d['nama_fakta']; ?></td>
                                    <td class="text-center"><a href="<?php echo base_url()."index.php/tampil/formeditfakta/".$d['kode']; ?>">Edit</a> | <a href="<?php echo base_url()."index.php/control_fakta/delete/".$d['kode']; ?>" onclick="return konfirmasi();">Delete</a></td>
                                </tr>

                              <?php $x++; } ?>
                            </body>
                        </table>
                    </div><!-- /.box-body -->
                </div><!-- /.box -->
              </div>
            </div>
        </div>

    </section><!-- /.content -->
</aside>
<script type="text/javascript" language="javascript">
function cekform(){
  if (!$("#kode").val())
  {
      alert("Kode Tidak Boleh Kosong");
      $("#kode").focus();
      return false;
  }
  if (!$("#fakta").val())
  {
      alert("Maaf, Fakta Tidak Boleh Kosong");
      $("#fakta").focus();
      return false;
  }
}

function konfirmasi()
{
  tanya = confirm("Anda Yakin Ingin Menghapus Data?");
  if (tanya == true)
  {
    return true;
  }
  else
  {
    return false;
  }
}

</script>
