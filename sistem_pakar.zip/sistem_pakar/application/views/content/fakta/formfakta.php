<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
          Fakta
          <small>Edit</small>
      </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-folder-o"></i> Fakta</a></li>
            <li class="active">Edit Fakta</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-success">
                    <div class="box-header">
                        <h3 class="box-title">Pembaruan Fakta</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <form action="<?php if($form=='1'){ echo base_url()."index.php/control_fakta/insert";} if($form=='2'){ echo base_url()."index.php/control_fakta/update";} ?>" method="post" onSubmit="return cekform()" role="form">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Kode Fakta</label>
                                <input type="text" class="form-control" name="kode" <?php if($form=='1') { echo "value=".$kode; } if($form=='2') { echo "value=".$hasil['kode']." readonly";  }?>>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Nama Fakta</label>
                                <input type="text" class="form-control" id="fakta" name="fakta" value="<?php if($form=='2') { echo $hasil['nama_fakta'];}?>" placeholder="Masukkan fakta">
                            </div>
                        </div><!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn bg-olive btn-primary">Ubah</button>
                            <!--<button  type="submit" class="btn btn-primary">Simpan</button>-->
                        </div>
                    </form>
                </div><!-- /.box -->
            </div>
        </div>
    </section><!-- /.content -->

    </section><!-- /.content -->
</aside><!-- /.right-side -->
<script type="text/javascript" language="javascript">
function cekform(){
  if (!$("#fakta").val())
  {
      alert("Maaf, Fakta Tidak Boleh Kosong");
      $("#fakta").focus();
      return false;
  }
}
</script>
