<?php
  $namadepan = $this->session->userdata('namadepan');
  $namabelakang = $this->session->userdata('namabelakang');
  $gambar = $this->session->userdata('gambar');
?>

<aside class="right-side">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Dashboard
                        <small></small>
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="#"><i class="fa fa-desktop"></i> Dashboard</a></li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
                    <!-- top row -->
                    <div class="row">
                        <div class="col-xs-12 connectedSortable">

                        </div><!-- /.col -->
                    </div>
                    <!-- /.row -->

                    <!-- Main row -->
                    <div class="row">
                        <!-- Left col -->
                        <section class="col-lg-3 connectedSortable">
                            <div class="box box-primary">
                                <div class="box-header center-block">
                                </div><!-- /.box-header -->
                                <div class="box-body">
                                    <div class="box-profile">
                                        <div class="center">
                                            <img src="<?php echo base_url()."assets/img/$gambar"; ?>" class="img-responsive center-block img-circle" alt="User Image" />
                                        </div>
                                        <hr>
                                        <h3 class="profile-username text-center"><?php echo "$namadepan $namabelakang"; ?></h3>
                                        <p class="text-muted text-center">Software Engineer</p>
                                    </div>
                                </div><!-- /.box-body -->
                            </div>
                            <div class="box box-primary">
                                <div class="box-header with-border">
                                    <h3 class="box-title">Tentang Saya</h3>
                                </div>
                                <div class="box-body">
                                    <strong><i class="fa fa-book margin-r-5"></i> Pendidikan</strong>
                                    <p class="text-muted">
                                        <i class="fa fa-angle-right"> S1 Teknik Informatika - Universitas Brawijaya Malang </i>
                                    </p>
                                    <hr>
                                    <strong><i class="fa fa-map-marker margin-r-5"></i> Lokasi</strong>
                                    <p class="text-muted">Jl. Bunga Dewandaru Dalam Rt.05 / Rw.02 Malang</p>
                                    <hr>
                                    <strong><i class="fa fa-pencil margin-r-5"></i> Keahlian/Hobi</strong>
                                    <p>
                                        <span class="label label-danger">PHP</span>
                                        <span class="label label-success">Database</span>
                                        <span class="label label-info">Futsal</span>
                                    </p>
                                    <hr>
                                    <strong><i class="fa fa-file-text-o margin-r-5"></i> Catatan</strong>
                                    <p>Belajar setiap hari. Jangan lewatkan hari tanpa ilmu. Pengalaman adalah ilmu yang berharga</p>
                                </div>
                            </div>

                        </section><!-- /.Left col -->
                        <!-- right col (We are only adding the ID to make the widgets sortable)-->
                        <section class="col-lg-9 connectedSortable">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="nav-tabs-custom">
                                        <ul class="nav nav-tabs">
                                            <li class="active"><a href="#tab_1" data-toggle="tab">Dashboard</a></li>
                                            <li><a href="#tab_2" data-toggle="tab">Tentang</a></li>
                                        </ul>
                                        <div class="tab-content">
                                            <div class="tab-pane active" id="tab_1">
                                                <div class="post">
                                                    <div class="user-block">
                                                        <h1><a href="#">Welcome</a></h1>
                                                        <span>Halaman Admin Rekap Data</span>
                                                    </div>
                                                    <!-- /.user-block -->
                                                    <p>
                                                        Selamat datang di halaman admin ini. ini merupakan website untuk membantu
                                                        dalam pengerjaan rekap data karyawan. semoga bisa bermanfaat kedepannya
                                                        dan senang dengan user interfacenya.
                                                    </p>
                                                </div>

                                            </div><!-- /.tab-pane -->
                                            <div class="tab-pane" id="tab_2">
                                                <form role="form">
                                                    <div class="box-body">
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">Employees Target</label>
                                                            <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter Target">
                                                        </div>

                                                    </div><!-- /.box-body -->

                                                    <div class="box-footer">
                                                        <button type="submit" class="btn btn-primary">Submit</button>
                                                    </div>
                                                </form>
                                            </div><!-- /.tab-pane -->

                                        </div><!-- /.tab-content -->
                                    </div><!-- nav-tabs-custom -->
                                </div><!-- /.col -->
                            </div>




                        </section><!-- right col -->
                    </div><!-- /.row (main row) -->

                </section><!-- /.content -->
            </aside>
