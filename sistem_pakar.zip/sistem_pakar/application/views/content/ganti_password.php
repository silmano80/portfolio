<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
          Ganti Password
          <small>Master</small>
      </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-pencil-square-o"></i> Ganti Password</a></li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-success">
                    <div class="box-header">
                        <h3 class="box-title">Ganti Password</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <form action="<?php echo base_url()."index.php/control_profil/updatepassword"; ?>" method="post" onSubmit="" role="form">
                        <div class="box-body">
                          <?php echo $this->session->flashdata('pesan'); ?>
                          <div class="form-group">
                              <label>Password Lama</label>
                              <input type="password" class="form-control"  id="pass_lama" name="pass_lama" placeholder="Masukkan Password Lama">
                          </div>
                          <div class="form-group">
                              <label>Password Baru</label>
                              <input type="password" class="form-control" id="pass_baru" name="pass_baru" placeholder="Masukkan Password Baru">
                          </div>
                          <div class="form-group">
                              <label>Confirm Password Baru</label>
                              <input type="password" class="form-control" id="con_pass" name="con_pass_baru" placeholder="Masukkan Confirm Password">
                          </div>
                        </div><!-- /.box-body -->
                        <div class="box-footer">
                            <button type="submit" class="btn bg-olive btn-primary">Ubah</button>
                            <!--<button  type="submit" class="btn btn-primary">Simpan</button>-->
                        </div>
                    </form>
                </div><!-- /.box -->
            </div>
        </div>
    </section><!-- /.content -->

    </section><!-- /.content -->
</aside><!-- /.right-side -->
<script type="text/javascript" language="javascript">
function cekform(){

  if (!$("#pass_lama").val())
  {
      alert("Maaf, Password Lama Tidak Boleh Kosong");
      $("#pass_lama").focus();
      return false;

  }

  if (!$("#pass_baru").val())
  {
      alert("Maaf, Password Baru Tidak Boleh Kosong");
      $("#pass_baru").focus();
      return false;

  }
  if (!$("#con_pass").val())
  {
      alert("Maaf, Konfirmasi Password Tidak Boleh Kosong");
      $("#con_pass").focus();
      return false;

  }
}
</script>
