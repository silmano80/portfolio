<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
          Foto
          <small>Ganti</small>
      </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-camera"></i> Ganti Foto</a></li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-success">
                    <div class="box-header">
                        <h3 class="box-title">Ganti Foto</h3>
                    </div><!-- /.box-header -->
                    <div id="pratinjauGambar" class="container">
                    </div>
                    <!-- form start -->
                    <form action="<?php echo base_url()."index.php/control_profil/updatefoto"?>" enctype="multipart/form-data" method="post" accept-charset="utf-8" onchange="return validasiFile()">
                      <div class="box-body">
                          <div class="form-group">
                              <label for="filefoto">File input</label>
                              <input type="file" name="filefoto" id="filefoto">
                          </div>
                      </div><!-- /.box-body -->

                      <div class="box-footer">
                          <button type="submit" onSubmit="return cekform()" class="btn btn-primary">Simpan</button>
                      </div>
                    </form>
                    <a href="<?php echo base_url()."index.php/control_profil/deletefoto"?>" class="pull-right">Reset Foto</a>
                </div><!-- /.box -->
            </div>
        </div>
    </section><!-- /.content -->

    </section><!-- /.content -->
</aside><!-- /.right-side -->

<script type="text/javascript" language="javascript">
function validasiFile(){
    var inputFile = document.getElementById('filefoto');
    var pathFile = inputFile.value;
    var ekstensiOk = /(\.jpg|\.jpeg|\.png|\.gif)$/i;
    console.log(inputFile);
    if(!ekstensiOk.exec(pathFile)){
        alert('Silakan upload file yang memiliki ekstensi .jpeg/.jpg/.png/.gif');
        inputFile.value = '';
        return false;
    }
}
</script>
