<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">

        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Tables</a></li>
            <li class="active">Data tables</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Master Goal</h3>
                    </div><!-- /.box-header -->

                    <div class="box-body table-responsive">
                        <table id="example1" class="table table-bordered table-striped">
                            <div class="contains">
                                <span>
                                    <a href="<?php echo base_url()."index.php/tampil/formgoal" ?>" class="btn btn-info">Tambah</a>
                                </span>
                            </div>
                                <br>
                            <thead>
                                <tr>
                                  <th class="text-center" style="width: 75px">No</th>
                                  <th style="width: 300px">Kode Goal</th>
                                  <th>Goal</th>
                                </tr>
                            </thead>
                            <tbody>
                              <?php $x=1; foreach ($hasil as $d) { ?>

                                <tr>
                                  <td class="text-center"><?php echo $x; ?></td>
                                    <td><?php echo $d['kode']; ?></td>
                                    <td><?php echo $d['nama_goal']; ?></td>
                                </tr>

                              <?php $x++; } ?>
                        </table>
                    </div><!-- /.box-body -->
                </div><!-- /.box -->
            </div>
        </div>

    </section><!-- /.content -->
</aside><!-- /.right-side -->
