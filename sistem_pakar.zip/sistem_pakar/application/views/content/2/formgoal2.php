<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <!--<h1>
            Penyakit
            <small>Preview page</small>
        </h1>-->
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Penyakit</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Tambah Goal</h3>
                    </div><!-- /.box-header -->

                    <!-- form start -->
                    <form action="<?php echo base_url()."index.php/control_goal/insert" ?>" method="post" onSubmit="" role="form" >
                        <div class="box-body">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Kode</label>
                                <input type="text" class="form-control" name="kode" id="exampleInputEmail1" placeholder="Masukkan kode">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Goal</label>
                                <input type="text" class="form-control" name="goal" id="exampleInputPassword1" placeholder="Masukkan goal">
                            </div>
                        </div><!-- /.box-body -->

                        <div class="box-footer">
                           <button type="submit" class="btn bg-olive btn-block">Simpan</button>
                           <!-- <button type="submit" class="btn btn-primary"><a href="formpenyakit1.html">Simpan</a></button>-->
                        </div>
                    </form>
                </div><!-- /.box -->
            </div>
        </div>
    </section><!-- /.content -->
</aside><!-- /.right-side -->
