<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tampil extends CI_Controller {
	function __construct()
	{
      parent:: __construct();
      $this->load->library('session');
      $this->load->model('crud_fakta');
      $this->load->model('crud_goal');
      $this->load->model('crud_pengetahuan');
			$this->load->model('crud_daftar');
      $this->model_security->secure_admin();
  	}

	public function index()
	{
		$data ['content'] = "content/dashboard";
		$data['aktif'] = 'dashboard';

		$this->load->view('index',$data);
	}

	public function mastergantipassword()
	{
		$data ['content'] = "content/ganti_password";
		$data['aktif'] = 'password';

		$this->load->view('index',$data);
	}

	public function mastergantifoto()
	{
		$data ['content'] = "content/ganti_foto";
		$data['aktif'] = '';
		$this->load->view('index',$data);
	}

	public function masterfakta()
	{
		$data ['content'] = "content/fakta/fakta";
		$data['aktif'] = 'fakta';
		$data['hasil'] = $this->crud_fakta->do_select();
		$data['kode'] = $this->crud_fakta->kode_otomatis();
		$this->load->view('index',$data);
	}

	public function mastergoal()
	{
		$data ['content'] = "content/goal/goal";
		$data['aktif'] = 'goal';
		$data['hasil'] = $this->crud_goal->do_select();
		$data['kode'] = $this->crud_goal->kode_otomatis();
		$this->load->view('index',$data);
	}

	public function masterpengetahuan()
	{
		$data ['content'] = "content/pengetahuan/pengetahuan";
		$data['aktif'] = 'pengetahuan';
		$data['pilihan_fakta'] = $this->crud_fakta->do_select();
		$data['pilihan_goal'] = $this->crud_goal->do_select();
		$data['hasil'] = $this->crud_pengetahuan->do_select();
		$this->load->view('index',$data);
	}

	public function masterdaftar()
	{
		$data ['content'] = "content/daftar/daftar";
		$data['aktif'] = 'daftar';
		$data['hasil'] = $this->crud_daftar->do_select();

		$this->load->view('index',$data);
	}

	public function formeditfakta($where)
	{
		$data ['content'] = "content/fakta/formfakta";
		$data['aktif'] = 'fakta';
		$data['form'] = '2';
		$data['hasil'] = $this->crud_fakta->do_select_where($where);

		// echo "<pre>";
		// print_r($data);
		// echo "</pre>";

		$this->load->view('index',$data);
	}

	public function formeditgoal($where)
	{
		$data ['content'] = "content/goal/formgoal";
		$data['aktif'] = 'goal';
		$data['form'] = '2';
		$data['hasil'] = $this->crud_goal->do_select_where($where);

		// echo "<pre>";
		// print_r($data);
		// echo "</pre>";

		$this->load->view('index',$data);
	}


	public function formeditpengetahuan($where)
	{
		$data ['content'] = "content/pengetahuan/formpengetahuan";
		$data['aktif'] = 'pengetahuan';
		$data['pilihan_fakta'] = $this->crud_fakta->do_select();
		$data['pilihan_goal'] = $this->crud_goal->do_select();
		$data['hasil'] = $this->crud_pengetahuan->do_select_where($where);
		// echo "<pre>";
		// print_r($data);
		// echo "</pre>";

		$this->load->view('index',$data);
	}

	public function formeditdaftar($where)
	{
		$data ['content'] = "content/daftar/formdaftar";
		$data['aktif'] = 'daftar';
		$data['hasil'] = $this->crud_daftar->do_select_where($where);

		// echo "<pre>";
		// print_r($data);
		// echo "</pre>";

		$this->load->view('index',$data);
	}

}
