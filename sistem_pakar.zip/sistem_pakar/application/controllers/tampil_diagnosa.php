<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tampil_diagnosa extends CI_Controller {
	function __construct()
	{
      parent:: __construct();
      $this->load->library('session');
			$this->load->model('model_diagnosa');
      $this->model_security->secure_pengguna();
  	}

	public function index()
	{
		$data ['content'] = "content/dashboard_diagnosa";
		$data['aktif'] = 'dashboard';

		$this->load->view('index_diagnosa',$data);
	}

	public function mastergantipassword()
	{
		$data ['content'] = "content/ganti_password";
		$data['aktif'] = 'password';

		$this->load->view('index_diagnosa',$data);
	}

	public function masterdiagnosa_awal()
	{
		$data ['content'] = "content/diagnosa/content_awal_diagnosa";
		$data['aktif'] = 'diagnosa';

		$this->load->view('index_diagnosa',$data);
	}

	public function masterdiagnosa()
	{
		$data ['content'] = "content/diagnosa/content_diagnosa";
		$data['aktif'] = 'diagnosa';
		if(isset($_POST['mulai'])){
			$data['hasil'] = $this->model_diagnosa->do_select();
			$this->load->view('index_diagnosa',$data);
		}
		else if(isset($_POST['jawaban'])){
			$data['hasil'] = $this->model_diagnosa->do_select_where($_POST['jawaban']);
			if (empty($data['hasil']))
			{
				$this->akhir();
			}
			else {
				$this->load->view('index_diagnosa',$data);
			}
		}
		else {
			show_404();
		}

	}

	public function akhir()
	{
		$data ['content'] = "content/diagnosa/content_akhir_diagnosa";
		$data['aktif'] = 'diagnosa';
		$data['hasil'] = $this->model_diagnosa->do_select_goal($_POST['jawaban']);
		if(empty($data['hasil']))
		{
			show_404();
		}
		$this->load->view('index_diagnosa',$data);
	}

	public function mastergantifoto()
	{
		$data ['content'] = "content/ganti_foto";
		$data['aktif'] = 'foto';
		$this->load->view('index_diagnosa',$data);
	}



}
