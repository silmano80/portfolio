<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Control_profil extends CI_Controller {
	function __construct()
	{
      parent:: __construct();
      $this->load->library('session');
      $this->load->model('crud_profil');
      $this->model_security->secure_login();
  	}

	public function updatepassword()
	{
		$username = $this->session->userdata('username');
		$passlama = md5($this->input->post('pass_lama'));
		$passbaru = $this->input->post('pass_baru');
		$conpassbaru = $this->input->post('con_pass_baru');

		$cekpass = $this->crud_profil->do_select_where($username,$passlama);
		// echo "<pre>";
		// print_r($cekpass);
		// echo "</pre>";
		if($cekpass == 1){
			if($passbaru==$conpassbaru){
				$data = array(
					'password' => md5($conpassbaru)
				 );
				 $where = array(
					 'username' => $username
				 );

				 $this->crud_profil->do_update('login',$data,$where);
				 redirect('index.php/login_control/logout');
			}
			else {
				$this->session->set_flashdata("pesan","<div class='alert alert-success'><strong>Maaf!</strong>Password Baru Tidak Cocok Dengan Confirm Password</div>");
				$this->dairek_password();
			}
		}
		else {
			$this->session->set_flashdata("pesan","<div class='alert alert-success'><strong>Maaf!</strong> Password Lama Tidak Sesuai</div>");
			$this->dairek_password();
		}
	}

	public function delete($kode)
	{
		$tabel = "fakta";
		$where = array(
			'kode' => $kode
		);
		$cek = $this->crud_fakta->do_delete($tabel, $where);
		if($cek>=1){
			redirect('index.php/tampil/masterfakta');
		}
		else {
			$this->session->set_flashdata("pesan","<div class='alert alert-success'><strong>Sorry!</strong>I think you incorrectly entered the data</div>");
		 redirect('index.php/tampil/masterfakta');
		}

	}

	public function dairek_password()
	{
		$level = $this->session->userdata('level');
		if($level==1){
			redirect('index.php/tampil/mastergantipassword');
		}
		else {
		 redirect('index.php/tampil_diagnosa/mastergantipassword');
		}
	}

	public function direk_foto()
	{
		$level = $this->session->userdata('level');
		if($level==1){
			redirect('index.php/tampil/mastergantifoto');
		}
		else {
		 redirect('index.php/tampil_diagnosa/mastergantifoto');
		}
	}

	public function updatefoto()
	{
		$username = $this->session->userdata('username');
		$config['upload_path'] = realpath('assets/img');
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size'] = '2000000';
    $config['max_width'] = '2024';
    $config['max_height']= '1468';

		$this->load->library('upload', $config);
 		$this->upload->initialize($config);

    if ($this->upload->do_upload('filefoto'))
    {
				$img = $this->upload->data();
				$gambar = $img['file_name'];
				$data = array(
					'gambar' => $gambar
				);
				$where = array(
					'username' => $username
				);

				$this->crud_profil->do_update('login',$data,$where);
				$this->session->set_userdata('gambar',$gambar);
				$this->direk_foto();
    }
    else
    {
            echo "gagal";
    }

	}

	function deletefoto()
  {
			$username = $this->session->userdata('username');
			$gambar = "avatarrr.jpg";
			$data = array(
				'gambar' => $gambar
			);
			$where = array(
				'username' => $username
			);
			$gam = $this->crud_profil->do_where_gambar('login',$where);
			$picture = $gam['gambar'];
			if($picture!=$gambar){
				unlink("assets/img/".$picture);
				$cek = $this->crud_profil->do_update('login',$data,$where);
				if($cek>0){
					$this->session->set_userdata('gambar',$gambar);
					$this->direk_foto();
				}
			}
			else {
				$this->direk_foto();
			}

  }

}
