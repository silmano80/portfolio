<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Control_daftar extends CI_Controller {
	function __construct()
	{
      parent:: __construct();
      $this->load->library('session');
      $this->load->model('crud_daftar');
      $this->model_security->secure_admin();
  	}

	public function insert()
	{
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$con_password = $this->input->post('con_password');
		$namadepan = $this->input->post('nama_depan');
		$namabelakang = $this->input->post('nama_belakang');
		$gambar = "avatarrr.jpg";
		$level = $this->input->post('level');

		 if($password==$con_password){
			 $data = array(
	 			'username' => $username,
	 			'password' => md5($password),
	 			'nama_depan' => $namadepan,
	 			'nama_belakang' => $namabelakang,
	 			'gambar' => $gambar,
	 			'id_level' => $level,
	 		 );
			 $cek = $this->crud_daftar->do_insert('login',$data);
			 if($cek>=1){
				 redirect('index.php/tampil/masterdaftar');
			 }
		 }
		 else {
		 	$this->session->set_flashdata("pesan","<div class='alert alert-success'><strong>Maaf !</strong> Password Tidak Cocok</div>");
			redirect('index.php/tampil/masterdaftar');
		 }
	}


	public function update()
	{
		$username = $this->input->post('username');
		$namadepan = $this->input->post('nama_depan');
		$namabelakang = $this->input->post('nama_belakang');
		$level = $this->input->post('level');

		$data = array(
			'username' => $username,
			'nama_depan' => $namadepan,
			'nama_belakang' => $namabelakang,
			'id_level' => $level
		 );
		 $where = array(
			 'username' => $username
		 );
		 $cek = $this->crud_daftar->do_update('login',$data,$where);
		 if($cek>=1){
			 redirect('index.php/tampil/masterdaftar');
		 }
		 else {
			 $this->session->set_flashdata("pesan","<div class='alert alert-success'><strong>Sorry!</strong>I think you incorrectly entered the data</div>");
 			redirect('index.php/tampil/formeditdaftar');
		 }

	}

	public function delete($username)
	{
		$tabel = "login";
		$where = array(
			'username' => $username
		);
		$cek = $this->crud_daftar->do_delete($tabel, $where);
		if($cek>=1){
			redirect('index.php/tampil/masterdaftar');
		}
		else {
			$this->session->set_flashdata("pesan","<div class='alert alert-success'><strong>Sorry!</strong>I think you incorrectly entered the data</div>");
		 redirect('index.php/tampil/masterfakta');
		}

	}

}
