<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_control extends CI_Controller {

	public function index(){
		$this->load->view('login');
	}

	public function login()
	{
		$user = $this->input->post('username');
		$pass = $this->input->post('password');
		$bar = $this->login_model->login($user,$pass);

		if($bar->num_rows() == 1){
			foreach ($bar->result_array() as $s) {
			$data_session = array(
			'username' => $user,
			'namadepan' => $s['nama_depan'],
			'namabelakang' => $s['nama_belakang'],
			'gambar' => $s['gambar'],
			'level' => $s['id_level']
			);
			}

		// echo "<pre>";
		// print_r($data_session);
		// echo "</pre>";

			$this->session->set_userdata($data_session);
			if($data_session['level']=='1')
			{
				redirect('index.php/tampil');
			}
			if($data_session['level']=='2')
			{
				redirect('index.php/tampil_diagnosa');
			}
			
		}
		else
		{
			$this->session->set_flashdata("pesan","<div class='alert alert-success'><strong>Sorry!</strong>I think you incorrectly entered the data</div>");
			redirect('index.php/login_control/');

		}

	}

	public function logout()
    {
			$this->session->sess_destroy();
			redirect('index.php/login_control','refresh');
    }


}

?>
