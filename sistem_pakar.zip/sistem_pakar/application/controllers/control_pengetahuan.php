<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Control_pengetahuan extends CI_Controller {
	function __construct()
	{
      parent:: __construct();
      $this->load->library('session');
      $this->load->model('crud_pengetahuan');
      $this->model_security->secure_admin();
  	}

	public function insert()
	{
		echo "masuk";
		$kodefakta = $this->input->post('fakta');
		$jawabya = $this->input->post('jwya');
		$jawabtdk = $this->input->post('jwtdk');
		$kodeya = $this->input->post('k_ya');
		$kodetdk = $this->input->post('k_tdk');

		$data = array(
			'kode_fakta' => $kodefakta,
			'jawabya' => $jawabya,
			'jawabtdk' => $jawabtdk,
			'ya' => $kodeya,
			'tdk' => $kodetdk
		 );
		 $cek = $this->crud_pengetahuan->do_insert('pengetahuan',$data);
		 if($cek>=1){
			 redirect('index.php/tampil/masterpengetahuan');
		 }
		 else {
			 $this->session->set_flashdata("pesan","<div class='alert alert-success'><strong>Sorry!</strong>I think you incorrectly entered the data</div>");
 			redirect('index.php/tampil/formpengetahuan');
		 }

	}

	public function update()
	{
		$kode_pengetahuan = $this->input->post('k_pengetahuan');
		$fakta = $this->input->post('fakta');
		$jawabya = $this->input->post('jwya');
		$jawabtdk = $this->input->post('jwtdk');
		$ya = $this->input->post('k_ya');
		$tdk = $this->input->post('k_tdk');

		$data = array(
			'kode_fakta' => $fakta,
			'jawabya' => $jawabya,
			'jawabtdk' => $jawabtdk,
			'ya' => $ya,
			'tdk' => $tdk
		 );
		 $where = array(
			 'kode_pengetahuan' => $kode_pengetahuan
		 );

		// echo "<pre>";
 		// print_r($data);
		// print_r($where);
 		// echo "</pre>";
		 $cek = $this->crud_pengetahuan->do_update('pengetahuan',$data,$where);
		 if($cek>=1){
			 redirect('index.php/tampil/masterpengetahuan');
		 }
		 else {
			 $this->session->set_flashdata("pesan","<div class='alert alert-success'><strong>Sorry!</strong>I think you incorrectly entered the data</div>");
 			redirect('index.php/tampil/formeditpengetahuan');
		 }

	}

	public function delete($kode_pengetahuan)
	{
		$tabel = "pengetahuan";
		$where = array(
			'kode_pengetahuan' => $kode_pengetahuan
		);
		$cek = $this->crud_pengetahuan->do_delete($tabel, $where);
		if($cek>=1){
			redirect('index.php/tampil/masterpengetahuan');
		}
		else {
			$this->session->set_flashdata("pesan","<div class='alert alert-success'><strong>Sorry!</strong>I think you incorrectly entered the data</div>");
		 redirect('index.php/tampil/masterpengetahuan');
		}
	}

}
