<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Control_goal extends CI_Controller {
	function __construct()
	{
      parent:: __construct();
      $this->load->library('session');
      $this->load->model('crud_goal');
      $this->model_security->secure_admin();
  	}

	public function insert()
	{
		$kode = $this->input->post('kode');
		$goal = $this->input->post('goal');
		$data = array(
			'kode' => $kode,
			'nama_goal' => $goal
		 );
		 $cek = $this->crud_goal->do_insert('goal',$data);
		 if($cek>=1){
			 redirect('index.php/tampil/mastergoal');
		 }
		 else {
			 $this->session->set_flashdata("pesan","<div class='alert alert-success'><strong>Sorry!</strong>I think you incorrectly entered the data</div>");
 			redirect('index.php/tampil/formgoal');
		 }

	}

	public function update()
	{
		$kode = $this->input->post('kode');
		$goal = $this->input->post('goal');
		$data = array(
			'kode' => $kode,
			'nama_goal' => $goal
		 );
		 $where = array(
			 'kode' => $kode
		 );
		 $cek = $this->crud_goal->do_update('goal',$data,$where);
		 if($cek>=1){
			 redirect('index.php/tampil/mastergoal');
		 }
		 else {
			 $this->session->set_flashdata("pesan","<div class='alert alert-success'><strong>Sorry!</strong>I think you incorrectly entered the data</div>");
 			redirect('index.php/tampil/formeditgoal');
		 }

	}

	public function delete($kode)
	{
		$tabel = "goal";
		$where = array(
			'kode' => $kode
		);
		$cek = $this->crud_goal->do_delete($tabel, $where);
		if($cek>=1){
			redirect('index.php/tampil/mastergoal');
		}
		else {
			$this->session->set_flashdata("pesan","<div class='alert alert-success'><strong>Sorry!</strong>I think you incorrectly entered the data</div>");
		 redirect('index.php/tampil/mastergoal');
		}
	}

}
