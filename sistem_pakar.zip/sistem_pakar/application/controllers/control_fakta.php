<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Control_fakta extends CI_Controller {
	function __construct()
	{
      parent:: __construct();
      $this->load->library('session');
      $this->load->model('crud_fakta');
      $this->model_security->secure_admin();
  	}

	public function insert()
	{
		$kode = $this->input->post('kode');
		$fakta = $this->input->post('fakta');
		$data = array(
			'kode' => $kode,
			'nama_fakta' => $fakta
		 );
		 $cek = $this->crud_fakta->do_insert('fakta',$data);
		 if($cek>=1){
			 redirect('index.php/tampil/masterfakta');
		 }
		 else {
			 $this->session->set_flashdata("pesan","<div class='alert alert-success'><strong>Sorry!</strong>I think you incorrectly entered the data</div>");
 			redirect('index.php/tampil/formfakta');
		 }

	}


	public function update()
	{
		$kode = $this->input->post('kode');
		$fakta = $this->input->post('fakta');
		$data = array(
			'kode' => $kode,
			'nama_fakta' => $fakta
		 );
		 $where = array(
			 'kode' => $kode
		 );
		 $cek = $this->crud_fakta->do_update('fakta',$data,$where);
		 if($cek>=1){
			 redirect('index.php/tampil/masterfakta');
		 }
		 else {
			 $this->session->set_flashdata("pesan","<div class='alert alert-success'><strong>Sorry!</strong>I think you incorrectly entered the data</div>");
 			redirect('index.php/tampil/formeditfakta');
		 }

	}

	public function delete($kode)
	{
		$tabel = "fakta";
		$where = array(
			'kode' => $kode
		);
		$cek = $this->crud_fakta->do_delete($tabel, $where);
		if($cek>=1){
			redirect('index.php/tampil/masterfakta');
		}
		else {
			$this->session->set_flashdata("pesan","<div class='alert alert-success'><strong>Sorry!</strong>I think you incorrectly entered the data</div>");
		 redirect('index.php/tampil/masterfakta');
		}

	}

}
