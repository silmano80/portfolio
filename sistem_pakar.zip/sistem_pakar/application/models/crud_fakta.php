<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud_fakta extends CI_Model {



	public function do_insert($tbl,$data)
	{
		return $this->db->insert($tbl,$data);
	}

	public function do_select()
	{
		return $this->db->get('fakta')->result_array();
	}

	public function do_select_where($where)
	{
		$aw = $this->db->get_where('fakta', array('kode' => $where ))->result_array();
		return $aw[0];

	}

	public function do_update($tabel,$data,$where)
	{
		return $this->db->update($tabel, $data, $where);

	}

	public function do_delete($tabel,$where)
	{
		return $this->db->delete($tabel, $where);

	}

	public function kode_otomatis()   {
		  // $this->db->select('RIGHT(kode,2) as kode', FALSE);
		  $this->db->order_by('kode','DESC');
		  $this->db->limit(1);
		  $query = $this->db->get('fakta');      //cek dulu apakah ada sudah ada kode di tabel.
		  if($query->num_rows() > 0){
		   //jika kode ternyata sudah ada.
			 if(preg_match("(\d*\d)",$query->row()->kode,$s)){
				 $nil = $s[0];
			 }
			 $kode = intval($nil)+1;
		  }
		  else {
		   //jika kode belum ada
		   $kode = 1;
		  }
		  $kodemax = str_pad($kode, 2, "0", STR_PAD_LEFT); // angka 4 menunjukkan jumlah digit angka 0
		  $kodejadi = "F".$kodemax;    // hasilnya ODJ-9921-0001 dst.
		  return $kodejadi;
	}

}
