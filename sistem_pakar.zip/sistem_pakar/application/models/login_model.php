<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model {

	public function login($us,$ps)
	{
		$user = $us;
		$pass = md5($ps);

		$this->db->where('username',$user);
		$this->db->where('password',$pass);
		return $this->db->get('login');

	}



}
