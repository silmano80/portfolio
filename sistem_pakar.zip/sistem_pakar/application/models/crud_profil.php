<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud_profil extends CI_Model {

	public function do_select_where($user,$passlama)
	{
		$this->db->where('username',$user);
		$this->db->where('password',$passlama);
		return $this->db->get('login')->num_rows();

	}

	public function do_update($tabel,$data,$where)
	{
		return $this->db->update($tabel, $data, $where);

	}

	public function do_where_gambar($tabel,$username)
	{
		return $this->db->get_where($tabel,$username)->row_array();
	}

}
