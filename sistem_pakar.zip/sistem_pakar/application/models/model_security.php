<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_security extends CI_Model {
    public function secure_admin() {
        $username = $this->session->userdata('username');
        $level = $this->session->userdata('level');
        if(empty($username)||($level!='1'))
        {
            $this->session->sess_destroy();
            redirect('index.php/login_control/');
        }

    }

    public function secure_pengguna() {
        $username = $this->session->userdata('username');
        $level = $this->session->userdata('level');
        if(empty($username)||($level!='2'))
        {
            $this->session->sess_destroy();
            redirect('index.php/login_control/');
        }

    }

    public function secure_login() {
        $username = $this->session->userdata('username');
        $level = $this->session->userdata('level');
        if(empty($username))
        {
            $this->session->sess_destroy();
            redirect('index.php/login_control/');
        }

    }



}
