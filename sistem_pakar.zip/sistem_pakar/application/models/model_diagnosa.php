<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_diagnosa extends CI_Model {


	public function do_select()
	{
		$this->db->limit(1);
		$this->db->join('fakta','fakta.kode=pengetahuan.kode_fakta');
		$cek = $this->db->get('pengetahuan')->row_array();
		if($cek > 0)
		{
			return $cek;
		}
		else
		{
			redirect('index.php/tampil_diagnosa/masterdiagnosa_awal');
			return false;
		}
	}

	public function do_select_where($where)
	{

		$this->db->join('fakta','fakta.kode=pengetahuan.kode_fakta');
		$aw = $this->db->get_where('pengetahuan', array('kode_fakta' => $where ))->row_array();
		return $aw;

	}

	public function do_select_goal($where)
	{
		$aw = $this->db->get_where('goal', array('kode' => $where ))->row_array();
		return $aw;

	}

}
