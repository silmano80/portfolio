<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud_pengetahuan extends CI_Model {



	public function do_insert($tbl,$data)
	{
		return $this->db->insert($tbl,$data);
	}

	public function do_select()
	{
		return $this->db->get('pengetahuan')->result_array();
	}

	public function do_select_where($where)
	{
		$aw = $this->db->get_where('pengetahuan', array('kode_pengetahuan' => $where ))->result_array();
		return $aw[0];

	}

	public function do_update($tabel,$data,$where)
	{
		return $this->db->update($tabel, $data, $where);

	}

	public function do_delete($tabel,$where)
	{
		return $this->db->delete($tabel, $where);

	}

	
}
