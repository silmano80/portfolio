-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2018 at 03:33 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sistempakar`
--

-- --------------------------------------------------------

--
-- Table structure for table `fakta`
--

CREATE TABLE `fakta` (
  `kode` varchar(4) NOT NULL,
  `nama_fakta` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fakta`
--

INSERT INTO `fakta` (`kode`, `nama_fakta`) VALUES
('F01', 'Sumber Modal Sendiri'),
('F02', 'Sumber Modal Hutang'),
('F03', 'Jumlah Modal Mikro'),
('F04', 'Jumlah Modal Menengah'),
('F05', 'Kemasan Bahan Plastik'),
('F06', 'Kemasan Bahan Sterofoam'),
('F07', 'Desain Kemasan Tradisional'),
('F08', 'Desain Kemasan Modern'),
('F09', 'Jumlah Rekanan <= 25'),
('F10', 'Jumlah Rekanan > 25'),
('F10A', 'Jumlah Rekanan Lebih Dari 25'),
('F10B', 'Jumlah Rekan > 25'),
('F11', 'Lokasi Mudah diAkses'),
('F11A', 'Akses Lokasi Mudah'),
('F11B', 'Mudah Akses Lokasinya'),
('F12', 'Lokasi Sulit di Akses'),
('F13', 'Tingkat Pendidikan SMA sederajat'),
('F13A', 'Pendidikan SLTA sederajat'),
('F14', 'Tingkat Pendidikan Lebih Dari SMA'),
('F15', 'Pernah Pelatihan'),
('F16', 'Tidak Pernah Ikut Pelatihan'),
('F16A', 'Tidak Pernah Mengikuti Pelatihan'),
('F17', 'Pengalaman > 2thn'),
('F17A', 'Lebih Dari 2thn Penglaman'),
('F18', 'Pengalaman <= 2thn'),
('F19', 'Sumber Modal Kombinasi'),
('F20', 'Jumlah Modal Kecil');

-- --------------------------------------------------------

--
-- Table structure for table `goal`
--

CREATE TABLE `goal` (
  `kode` varchar(4) NOT NULL,
  `nama_goal` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `goal`
--

INSERT INTO `goal` (`kode`, `nama_goal`) VALUES
('G01', 'Anda Harus Pengembangan Pasar'),
('G02', 'Anda Harus Pengembangan Produk'),
('G03', 'Tidak Menemukan Solusi');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(30) NOT NULL,
  `password` varchar(60) DEFAULT NULL,
  `nama_depan` varchar(20) DEFAULT NULL,
  `nama_belakang` varchar(30) DEFAULT NULL,
  `gambar` varchar(30) DEFAULT NULL,
  `id_level` enum('1','2') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `nama_depan`, `nama_belakang`, `gambar`, `id_level`) VALUES
('alan', '02558a70324e7c4f269c69825450cec8', 'Alan', 'Primandana', 'alan.jpg', '1');

-- --------------------------------------------------------

--
-- Table structure for table `pengetahuan`
--

CREATE TABLE `pengetahuan` (
  `kode_pengetahuan` int(11) NOT NULL,
  `kode_fakta` varchar(4) DEFAULT NULL,
  `jawabya` text,
  `jawabtdk` text,
  `ya` varchar(4) DEFAULT NULL,
  `tdk` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengetahuan`
--

INSERT INTO `pengetahuan` (`kode_pengetahuan`, `kode_fakta`, `jawabya`, `jawabtdk`, `ya`, `tdk`) VALUES
(1, 'F01', 'Iya, Modalnya Sendiri', 'Tidak', 'F03', 'F02'),
(2, 'F02', 'Iya', 'Tidak', 'F05', 'F19'),
(3, 'F03', 'Iya', 'Tidak', 'F08', 'F10'),
(4, 'F08', 'Iya', 'Tidak', 'F12', 'F10A'),
(5, 'F12', 'Iya', 'Tidak', 'F17', 'F13'),
(6, 'F17', 'Iya', 'Tidak', 'G01', 'G02'),
(7, 'F13', 'Iya', 'Tidak', 'G02', 'G01'),
(8, 'F10A', 'Iya', 'Tidak', 'F11', 'G02'),
(9, 'F11', 'Iya Mudah', 'Tidak Terlalu', 'G01', 'F14'),
(10, 'F14', 'Iya', 'Tidak', 'G01', 'G02'),
(11, 'F10', 'Iya', 'Tidak', 'F11A', 'F20'),
(12, 'F11A', 'Iya', 'Tidak', 'G01', 'G02'),
(13, 'F05', 'Iya', 'Tidak', 'F10B', 'F11B'),
(14, 'F13A', 'Iya', 'Tidak', 'F16', 'G02'),
(15, 'F16', 'Iya Tidak Pernah', 'Pernah Ikut', 'G02', 'G01'),
(16, 'F04', 'Iya', 'Tidak', 'F17A', 'G03'),
(17, 'F17A', 'Iya', 'Tidak', 'G01', 'G02'),
(18, 'F11B', 'Iya, Mudah', 'Tidak, Sulit', 'F18', 'G01'),
(19, 'F18', 'Iya', 'Tidak', 'G02', 'F16A'),
(20, 'F16A', 'Iya', 'Tidak', 'G01', 'G03'),
(21, 'F10B', 'Iya', 'Tidak', 'F13A', 'G02'),
(22, 'F19 ', 'Ya', 'Tidak', 'F10', 'F10A'),
(23, 'F20 ', 'Iya', 'Tidak', 'G01', 'G03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fakta`
--
ALTER TABLE `fakta`
  ADD PRIMARY KEY (`kode`);

--
-- Indexes for table `goal`
--
ALTER TABLE `goal`
  ADD PRIMARY KEY (`kode`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pengetahuan`
--
ALTER TABLE `pengetahuan`
  ADD PRIMARY KEY (`kode_pengetahuan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pengetahuan`
--
ALTER TABLE `pengetahuan`
  MODIFY `kode_pengetahuan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
