<?php

require_once("db/db.php");
$dbHost = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "data_suhu";
$db = new Db();

define("TAG_OPEN","{");
define("TAG_CLOSE","}");
define("SUCCESS", 1);
define("FAILED", 0);

$signal=FAILED;
$out="";
$action=$_GET['action'];
switch($action){
	case "suhu":
		if(isset($_GET['suhu1'])){
			$suhu1=$_GET['suhu1'];
			$suhu2=$_GET['suhu2'];
			$suhu3=$_GET['suhu3'];
			$suhu4=$_GET['suhu4'];
			$suhu5=$_GET['suhu5'];
			$suhu6=$_GET['suhu6'];
			
			$out="Suhu1= ".$suhu1." Suhu2= ".$suhu2." Suhu3= ".$suhu3." Suhu4= ".$suhu4." Suhu5= ".$suhu5." Suhu6= ".$suhu6;
			
			//##insert suhu
			$sql = "INSERT INTO `suhu` (`suhu1`, `suhu2`, `suhu3`, `suhu4`, `suhu5`, `suhu6`) 
					VALUES 
						('".$suhu1."', '".$suhu2."', '".$suhu3."', '".$suhu4."', '".$suhu5."', '".$suhu6."' )
					;
					";echo $sql;
			if(!$db->query($sql)){   //if failed
				$out='Gagal';
				$signal=FAILED;
			}
			else
				$signal=SUCCESS;
			
		}
		else 
			$signal=FAILED;
		break;
	case "getTime":
		//##get time
		$sql = "SELECT time
				FROM schedule
				;
				";
		if(!$time=$db->fetch($sql)){   //if failed
			$signal=FAILED;
			break;
		}
		$signal=SUCCESS;
		$time=json_decode($time);
		foreach($time as $data)
			$out.=$data->time.';';
		//$out='15:48:50;15:48:57;';
		break;
}


echo TAG_OPEN.$signal.$out.TAG_CLOSE;
//{115:48:50;15:48:57;}
?>
