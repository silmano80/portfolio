<?php
class Home_m extends Db{
	var $db;
	
	
	function __construct(){
		$this->db = new Db;
	}
	
	function getDataSuhu(){
		$sql="SELECT * FROM suhu order by timestamp DESC";
		if($data = $this->db->fetch($sql))
			return $data;
		else
			return false;
	}
	
}