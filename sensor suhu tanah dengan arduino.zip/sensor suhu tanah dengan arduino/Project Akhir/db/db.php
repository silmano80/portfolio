<?php

class Db{
    private $dbLink;
	private $dbHost = "localhost";
	private $dbUsername = "root";
    private $dbPassword = "";
	private $dbName = "data_suhu";
	public  $queryCount = 0;
	
	function __destruct()	{
		$this->close();
	}

	//connect to database
	private function connect() {	
		$this->dbLink = mysql_connect($this->dbHost, $this->dbUsername, $this->dbPassword);		
		if (!$this->dbLink)	{			
			$this->ShowError();
			return false;
		}
		else if (!mysql_select_db($this->dbName,$this->dbLink))	{
			$this->ShowError();
			return false;
		}
		else {
			mysql_query("set names latin5",$this->dbLink);
			return true;
		}
		unset ($this->dbHost, $this->dbUsername, $this->dbPassword, $this->dbName);		
	}	

	/*****************************
	 * Method to close connection *
	 *****************************/
	function close()	{
		@mysql_close($this->dbLink);
	}

	function ShowError(){
		return mysql_error();	
	}
	
	function query($sql){
		if (!$this->dbLink)	
			$this->connect();
		if (!$result=mysql_query($sql,$this->dbLink)) { 
			return false;
		}
		$this->queryCount++;	
		return $result;
	}
	/************************
	* Method to fetch values*
	*************************/
	/*function fetchRow($sql){
		$query=$this->query($sql);
		if($row=mysql_fetch_row($query))		
			return $row;
	}*/

	function fetch($sql){
		$query=$this->query($sql);
		while($data=mysql_fetch_assoc($query)){
		    $json[]=$data;
		}
		if(isset($json))
			return json_encode($json);
		else
			return null;
	}
    
    function fetchRow($sql){
		$query=$this->query($sql);
		$json=mysql_fetch_assoc($query);
		if(isset($json))
			return $json;
		else
			return null;
	}

	/*************************
	* Method to number of rows
	**************************/
	function numRows($sql){
		$result=$this->query($sql);
		if (false === ($num = mysql_num_rows($result))) {
			$this->ShowError();
			return -1;
		}
		return $num;		
	}

}
