<?php

require_once("mysql.php");
$dbHost = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "absensi";
$db = new MySQL($dbHost,$dbUsername,$dbPassword,$dbName);


define("TAG_OPEN","{");
define("TAG_CLOSE","}");
define("ERROR", 0);		//unknown error
define("SUCCESS", 1);
define("FAILED", 2);

define("ERR_FAILED_AUTH","Autentikasi Gagal");
define("ERR_NO_DEVICE","Device tidak ada");
define("ERR_NO_ROOM","Tidak ada ruangan");
define("ERR_NO_USER","User tidak ada");
define("ERR_NO_ABSENSI","Tidak ada jadwal");
define("ERR_FAILED_ABSENSI","Gagal Absen");
define("ERR_FAILED_ABSENSI_DONE","Sudah Absen");
define("ERR_FAILED_ABSENSI_MIN_TIME","menit lagi");
define("ERR_FAILED_ABSENSI_MAX_TIME","Telat");

define("TIME_BEFORE" ,20);
define("TIME_AFTER" ,5);
define("TIME_BEFORE2" ,40);

$TBL_user="user";
$COL_USER_id="id";
$COL_USER_name="name";

$TBL_rfid="rfid";
$COL_RFID_uid="uid";
$COL_RFID_id_user="id_user";

$TBL_rfid="rfid";
$COL_RFID_uid="uid";
$COL_RFID_id_user="id_user";

$TBL_device="device";
$COL_DEVICE_id="id";
$COL_DEVICE_id_room="id_room";
$COL_DEVICE_password="password";

$TBL_rfid_admin="rfid_admin";
$COL_RFID_ADMIN_id_device="id_device";
$COL_RFID_ADMIN_uid="uid";

$TBL_class="class";
$COL_CLASS_id_user='id_user';
$COL_CLASS_id_pk='id_pk';
$COL_CLASS_semester='semester';
$COL_CLASS_class='class';
$COL_CLASS_prak='prak';

$TBL_schedule="schedule";
$COL_SCHEDULE_id='id';
$COL_SCHEDULE_id_room='id_room';
$COL_SCHEDULE_id_course='id_course';
$COL_SCHEDULE_id_pk='id_pk';
$COL_SCHEDULE_semester='semester';
$COL_SCHEDULE_class='class';
$COL_SCHEDULE_ket='ket';
$COL_SCHEDULE_day='day';
$COL_SCHEDULE_time='time';
$COL_SCHEDULE_duration='duration';

$TBL_absensi="absensi";
$COL_ABSENSI_id_user="id_user";
$COL_ABSENSI_id_schedule="id_schedule";
$COL_ABSENSI_date="date";
$COL_ABSENSI_absen="absen";

$TBL_course="course";
$COL_COURSE_id="id";
$COL_COURSE_name="name";

$action = $_POST['action'];
$signal=ERROR;
$out="";

switch($action) {
	case "get_room":
		$device = $_POST['id'];
		$password = $_POST['password'];
        
        $sql = "SELECT * FROM `$TBL_rfid_admin`
				WHERE `$COL_RFID_ADMIN_id_device`='$device'
                    AND `$COL_RFID_ADMIN_uid`='$password'
				;
				";
		if($db->numRows($sql)<1){	//jika ada datanya
            $out=ERR_FAILED_AUTH;
			$signal=FAILED;
            break;
        }
        
		$sql = "SELECT `$COL_DEVICE_id_room` FROM `$TBL_device`
				WHERE `$COL_DEVICE_id`='$device'
				;
				";
		if($row=$db->fetchRow($sql)){	//jika ada datanya
            $out=$row[$COL_DEVICE_id_room]; //ambil room
            if($out==null){     //jika tidak ada ruangan yg terdaftar
                //$out=ERR_NO_ROOM;
                $signal=FAILED;
                break; 
            }
			$signal=SUCCESS;
		}
		else{
            //$out=ERR_NO_DEVICE;
			$signal=FAILED;
        }
	break;
	
    case "get_course": 
        //##ambil id room
        $device = $_POST['id'];
		$password = $_POST['password'];
		$sql = "SELECT * FROM `$TBL_rfid_admin`
				WHERE `$COL_RFID_ADMIN_id_device`='$device'
                    AND `$COL_RFID_ADMIN_uid`='$password'
				;
				";
		if($db->numRows($sql)<1){	//jika ada datanya
            $out=ERR_FAILED_AUTH;
			$signal=FAILED;
            break;
        }
        
        $id_room = $_POST['id_room'];
        date_default_timezone_set('Asia/Jakarta');
        $timezone = date_default_timezone_get();
        $date=date('Y-m-d', time());
        $hour2 = date('H:i:s',time());
        $hour=date('H:i:s',time()-3600);
		$sql = "SELECT *
                    FROM `$TBL_schedule` AS `s`
                    	LEFT JOIN `$TBL_course` AS `c` ON `s`.`$COL_SCHEDULE_id_course`=`c`.`$COL_COURSE_id`
                    	LEFT JOIN `$TBL_absensi` AS `a` ON `s`.`$COL_SCHEDULE_id`=`a`.`$COL_ABSENSI_id_schedule`
                    WHERE `s`.`$COL_SCHEDULE_id_room`='$id_room'
                    	AND `a`.`$COL_ABSENSI_date`='$date'
                        AND `s`.`$COL_SCHEDULE_time` BETWEEN '$hour' AND '$hour2'         
                    ORDER BY `s`.`$COL_SCHEDULE_time` ASC
                    LIMIT 1
				;
				";
        if($row=$db->fetchRow($sql)){	//jika ada datanya
            $out=$row[$COL_COURSE_name]; //ambil room
    		$signal=SUCCESS;
        }
        else
            $signal=FAILED;
    break;
	
	case "absen": 
        //##ambil id room
        $device = $_POST['id'];
		$password = $_POST['password'];
        $id_room = $_POST['id_room'];
		$sql = "SELECT * FROM `$TBL_rfid_admin`
				WHERE `$COL_RFID_ADMIN_id_device`='$device'
                    AND `$COL_RFID_ADMIN_uid`='$password'
				;
				";
		if($db->numRows($sql)<1){	//jika ada datanya
            $out=ERR_FAILED_AUTH;
			$signal=FAILED;
            break;
        }
        
        //##ambil id user
        $uid = $_POST['uid'];
        $sql = "SELECT `$COL_RFID_id_user` FROM `$TBL_rfid`
				WHERE `$COL_RFID_uid`='$uid'
				;
				";
        if(!$json=$db->fetchRow($sql)){    //jika tidak ada datanya
            $out=ERR_NO_USER;
			$signal=FAILED;
            break;
        }
        $id_user=$json[$COL_RFID_id_user];
        
        //##ambil data user
        $sql = "SELECT * FROM `$TBL_class`
				WHERE `$COL_CLASS_id_user`='$id_user'
				;
				";
        if(!$json=$db->fetchRow($sql)){    //jika tidak ada datanya
			$signal=FAILED;
            break;
        }
        $sql = "SELECT $COL_SCHEDULE_id, $COL_SCHEDULE_time, $COL_SCHEDULE_id_course, $COL_SCHEDULE_duration 
                FROM `$TBL_schedule`
				WHERE `$COL_SCHEDULE_id_pk`='$json[$COL_CLASS_id_pk]'
                    AND `$COL_SCHEDULE_semester`='$json[$COL_CLASS_semester]'
                    AND `$COL_SCHEDULE_class`='$json[$COL_CLASS_class]'
                    AND `$COL_SCHEDULE_id_room`='$id_room'
				;
				";
        if(!$json=$db->fetchRow($sql)){
			$signal=FAILED;
            break;
        }
        $id_course=$json[$COL_SCHEDULE_id_course];
        
        //##cek apakah ada absensi ada di schedule hari itu
        date_default_timezone_set('Asia/Jakarta');
        $timezone = date_default_timezone_get();
        $date=date('Y-m-d', time());
        $sql = "SELECT * FROM `$TBL_absensi`
				WHERE `$COL_ABSENSI_date`='$date'
                    AND `$COL_ABSENSI_id_schedule`='$json[$COL_SCHEDULE_id]'
                LIMIT 1
				;
				";
        if(!$db->numRows($sql)>0){ //jika tidak ada jadwal di absensi
            $out=ERR_NO_ABSENSI;
            $signal=FAILED;
            break;
        }
        $id_schedule=$json[$COL_SCHEDULE_id];
        //##ambil schedule time. Hitung min_time (schedule_time dikurangi), hitung max_time (schedule_time ditambahi)  
        $schedule_time = $json[$COL_SCHEDULE_time];
        
        $hour = date('H',strtotime($schedule_time))*60;
        $minute = date('i',strtotime($schedule_time));
        $schedule_time=$hour+$minute;
        
        $min_time=$schedule_time-TIME_BEFORE;
        $max_time=$schedule_time+TIME_AFTER;
        
        $min2_time=$schedule_time-TIME_BEFORE2;
        $max2_time=$schedule_time+$json[$COL_SCHEDULE_duration];
        
        date_default_timezone_set('Asia/Jakarta');
        $timezone = date_default_timezone_get();
        $date=date('Y-m-d', time());
        
        $hour=date('H', time())*60;
        $minute=date('i', time());
        $current_time=$hour+$minute;
              
        
        //##jika belum waktunya absen (jauh beberapa menit sebelum batas waktu minumum)
        if($current_time<$min2_time){   //jika absen di bawah batas waktu minimum2
            $out=ERR_NO_ABSENSI;    //tidak ada jadwal
			$signal=FAILED;
            break;
        }
        //##jika jadwal (durasi kuliah) telah selesai
        if($current_time>$max2_time){ //jika absen di atas batas waktu maximum2
            $out=ERR_NO_ABSENSI;    //tidak ada jadwal
			$signal=FAILED;
            break;
        }
        
        //##cek apakah sudah absen
        $sql = "SELECT `$COL_ABSENSI_absen` 
                FROM `$TBL_absensi`
                				WHERE `$COL_ABSENSI_id_user`='$id_user'
                                    AND `$COL_ABSENSI_id_schedule`='$json[$COL_SCHEDULE_id]'
                                    AND `$COL_ABSENSI_date`='$date'
				;
				";
        if($json=$db->fetchRow($sql)){
			$absen=$json[$COL_ABSENSI_absen];
            if($absen!=NULL){  //jika sudah absen
                $out=ERR_FAILED_ABSENSI_DONE;
    			$signal=FAILED;
                break;
            }
        }
        
        //##jika belum waktunya absen (beberapa menit sebelum batas waktu minumum)
        if($current_time<$min_time){   //jika absen di bawah batas waktu minimum 
            $out=($min_time-$current_time)." ".ERR_FAILED_ABSENSI_MIN_TIME;
			$signal=FAILED;
            break;
        }
        //##jika telat
        if($current_time>$max_time){ //jika absen di atas batas waktu maximum
            $out=ERR_FAILED_ABSENSI_MAX_TIME;
			$signal=FAILED;
            break;
        }
        //##update table absensi, bahwa dia hadir
        $sql = "UPDATE `$TBL_absensi`
                SET `$COL_ABSENSI_absen`='1'
				WHERE `$COL_ABSENSI_id_user`='$id_user'
                    AND `$COL_ABSENSI_id_schedule`='$id_schedule'
                    AND `$COL_ABSENSI_date`='$date'
				;
				";
        $db->query($sql);
        if(mysql_affected_rows()==0){   //if failed
            $out=ERR_FAILED_ABSENSI;
			$signal=FAILED;
            break;
        }
        
        //##get the user name
        $sql = "SELECT `$COL_USER_name` FROM `$TBL_user`
				WHERE `$COL_USER_id`='$id_user'
				;
				";
        $name="unknown";
        if($json=$db->fetchRow($sql)){
			$name=$json[$COL_USER_name];
        }
        //##get the course name
        $sql = "SELECT `$COL_COURSE_name` FROM `$TBL_course`
				WHERE `$COL_COURSE_id`='$id_course'
				;
				";
        $course="unknown";
        if($json=$db->fetchRow($sql)){
			$course=$json[$COL_COURSE_name];
        }
        $signal=SUCCESS;
        $out=$name.";".$course;
    break;
    /*
    case "get_lesson": 
        //##ambil id room
        $device = $_POST['id'];
		$password = $_POST['password'];
		$sql = "SELECT `$COL_DEVICE_id_room` FROM `$TBL_device`
				WHERE `$COL_DEVICE_id`='$device'
                    AND `$COL_DEVICE_password`='$password'
				;
				";
		if($row=$db->fetchRow($sql)){	//jika ada datanya
            $id_room=$row[$COL_DEVICE_id_room]; //ambil room
            if($id_room==null){     //jika tidak ada ruangan yg terdaftar
                $out=ERR_NO_ROOM;
                $signal=FAILED;
                break; 
            }
		}
		else{
            $out=ERR_NO_DEVICE;
			$signal=FAILED;
            break;
        }	
        
        //##ambil id user
        $uid = $_POST['uid'];
        $sql = "SELECT `$COL_RFID_id_user` FROM `$TBL_rfid`
				WHERE `$COL_RFID_uid`='$uid'
				;
				";
        if(!$json=$db->fetchRow($sql)){    //jika tidak ada datanya
            $out=ERR_NO_USER;
			$signal=FAILED;
            break;
        }
        $id_user=$json[$COL_RFID_id_user];
        
        //##ambil data user
        $sql = "SELECT * FROM `$TBL_class`
				WHERE `$COL_CLASS_id_user`='$id_user'
				;
				";
        if(!$json=$db->fetchRow($sql)){    //jika tidak ada datanya
			$signal=FAILED;
            break;
        }
        
        $sql = "SELECT $COL_SCHEDULE_id, $COL_SCHEDULE_time, $COL_SCHEDULE_id_course, $COL_SCHEDULE_duration 
                FROM `$TBL_schedule`
				WHERE `$COL_SCHEDULE_id_pk`='$json[$COL_CLASS_id_pk]'
                    AND `$COL_SCHEDULE_semester`='$json[$COL_CLASS_semester]'
                    AND `$COL_SCHEDULE_class`='$json[$COL_CLASS_class]'
                    AND `$COL_SCHEDULE_id_room`='$id_room'
				;
				";
        if(!$json=$db->fetchRow($sql)){
			$signal=FAILED;
            break;
        }
    break;
    */    
}


function query($db,$sql){
	if($db->query($sql))
		return 1;
	else
		return 0;
}	

function get($db,$sql){
	$query=$db->query($sql);
	if($query){
		if($json=$db->fetch($query))
			return $json;
		else 
			return FAILED;
	}
	else 
		return ERROR;
}


echo TAG_OPEN.$signal.$out.TAG_CLOSE;

?>
