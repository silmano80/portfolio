<?php
	
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=pengukuran.xls");

	require_once("db/db.php");
	require_once("db/home_m.php");
	$m = new Home_m();
?>
	<table id="tableSuhu" class="tableSuhu" >
		<thead>
			<tr>
				<th>No</th>
				<th>Tanggal</th>
				<th>Waktu</th>
				<th>Suhu 2 cm</th>
				<th>Suhu 5 cm</th>
				<th>Suhu 10 cm</th>
				<th>Suhu 20 cm</th>
				<th>Suhu 50 cm</th>
				<th>Suhu 100 cm</th>
			</tr>
		</thead>
		<tbody>
		<?php
		
		$dataSuhu = json_decode($m->getDataSuhu());
		//print_r($dataSuhu);
		if($dataSuhu){
			$i=0;
			foreach($dataSuhu as $data){
				$i++;
			?>
				<tr>		
					<td><?php echo $i; ?></td>
					<td><?php echo substr($data->timestamp, 0, 10); ?></td>
					<td><?php echo substr($data->timestamp, 10, 9); ?></td>
					<td><?php echo $data->suhu1; ?></td>
					<td><?php echo $data->suhu2; ?></td>
					<td><?php echo $data->suhu3; ?></td>
					<td><?php echo $data->suhu4; ?></td>
					<td><?php echo $data->suhu5; ?></td>
					<td><?php echo $data->suhu6; ?></td>
				</tr>
			<?php
			}
		}
		?>
		</tbody>
	</table>