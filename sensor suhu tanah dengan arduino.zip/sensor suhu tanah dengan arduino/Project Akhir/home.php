<html>
<head>
	<meta http-equiv="refresh" content="10">
	<title>Data Suhu</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<script src="assets/js/jquery.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="assets/css/dataTables.bootstrap.css">
	<script type="text/javascript" src="assets/js/dataTables.bootstrap.min.js"></script>
	<script type="text/javascript" src="assets/js/jquery.dataTables.min.js"></script>
	<link rel="stylesheet" type="text/css" href="assets/css/jquery.dataTables.min.css">
	
	<link rel="stylesheet" href="assets/css/home.css">
	
	<script type="text/javascript">

	$(document).ready(function() {
		var table = $('#tableSuhu').DataTable({
			"language": {
			  "lengthMenu": "Tampilkan _MENU_ Baris data",
			  "zeroRecords": "Maaf, tidak ada data.",
			  "info": "Halaman Ke- _PAGE_ dari _PAGES_",
			  "infoEmpty": "No records available",
			  "infoFiltered": "(filtered from _MAX_ total records)",
			  "search": "Cari Semua"
			}
		});
		function filterColumn (e, i) {
			$('#tableSuhu').DataTable().column( i ).search(
				$(e).val()
			).draw();
		}
		$('input.column_filter').on( 'keyup click', function () {
			filterColumn(this, $(this).attr('data-column'));
		} );
		/*
		// Setup - add a text input to each footer cell
		$('#tableSuhu tfoot th').each( function () {
			var title = $(this).text();
			$(this).html( '<input type="text" placeholder="Search '+title+'" />' );
		} );
	 
		// Apply the search
		table.columns().every( function () {
			var that = this;
	 
			$( 'input', this.footer() ).on( 'keyup change', function () {
				if ( that.search() !== this.value ) {
					that
						.search( this.value )
						.draw();
				}
			} );
		} 
		*/
	} );
	</script>
		
</head>

<body>

	<?php
	
	require_once("db/db.php");
	require_once("db/home_m.php");
	$m = new Home_m();
	?>
	Tanggal: <input type="text" class="column_filter" data-column="1" placeholder="Cari Tanggal" "padding:10px"/>
	Waktu: <input type="text" class="column_filter" data-column="2" placeholder="Cari Waktu" />
	<button type="submit" onclick="window.open('./export_excel.php')" class="btn btn-primary">Download File</button></a>
	<table id="tableSuhu" class="table" >
		<thead>
			<tr>
				<th>No</th>
				<th>Tanggal</th>
				<th>Waktu</th>
				<th>Suhu pada 2 cm</th>
				<th>Suhu pada 5 cm</th>
				<th>Suhu pada 10 cm</th>
				<th>Suhu pada 20 cm</th>
				<th>Suhu pada 50 cm</th>
				<th>Suhu pada 100 cm</th>
			</tr>
		</thead>
		<tbody>
		<?php
		
		$dataSuhu = json_decode($m->getDataSuhu());
		//print_r($dataSuhu);
		if($dataSuhu){
			$i=0;
			foreach($dataSuhu as $data){
				$i++;
			?>
				<tr>		
					<td><?php echo $i; ?></td>
					<td><?php echo substr($data->timestamp, 0, 10); ?></td>
					<td><?php echo substr($data->timestamp, 10, 9); ?></td>
					<td><?php echo $data->suhu1; ?></td>
					<td><?php echo $data->suhu2; ?></td>
					<td><?php echo $data->suhu3; ?></td>
					<td><?php echo $data->suhu4; ?></td>
					<td><?php echo $data->suhu5; ?></td>
					<td><?php echo $data->suhu6; ?></td>
				</tr>
			<?php
			}
		}
		?>
		</tbody>
	</table>
</body>
</html>
