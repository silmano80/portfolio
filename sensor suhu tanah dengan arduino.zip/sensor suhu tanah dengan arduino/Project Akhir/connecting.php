<?php
   $dbHost = "localhost";
   $dbUsername = "root";
   $dbPassword = "";
   $dbName = "data_suhu";
   
   $conn = mysql_connect($dbHost, $dbUsername, $dbPassword, $dbName);
   
   if(! $conn ) {
      die("Could not connect: " . mysql_error());
   }
   
   $sql = "SELECT id, timestamp, temperature FROM suhu";
   mysql_select_db("data_suhu");
   $retval = mysql_query( $sql, $conn );
   
   if(! $retval ) {
      die("Could not get data: " . mysql_error());
   }
   
   while($row = mysql_fetch_array($retval, MYSQL_NUM)) {
      echo " id :{$row[0]}  <br> ".
         " timestamp : {$row[1]} <br> ".
         " temperature : {$row[2]} <br> ".
         "--------------------------------<br>";
   }
   
   mysql_free_result($retval);
   echo "Fetched data successfully\n";
   
   mysql_close($conn);
?>